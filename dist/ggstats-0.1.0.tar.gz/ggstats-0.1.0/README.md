# GG Stats

A package for evaluating metrics.
This packages can calculate specificty and sensitivty if TP, FN and FP are provided.
The package can also calcualte accuracy and PPV from both basic values such as TP,FN,FP,and TN but also from sensitivty and specificty and prevlance.

## Installation

```sh
pip install ggstats
